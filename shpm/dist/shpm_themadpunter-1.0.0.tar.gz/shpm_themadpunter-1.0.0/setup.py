""""""
from setuptools import setup

setup(
    name="shpm_themadpunter",
    version="0.1.0",
    author="Themadpunter",
    description = "A package manager for MIT Scratch"
)