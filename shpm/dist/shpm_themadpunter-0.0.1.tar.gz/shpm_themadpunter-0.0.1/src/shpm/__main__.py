#!/usr/bin/env python3
import argparse
import os
#Argument Parsing
parser = argparse.ArgumentParser()
parser.add_argument("cmd", help="The command you use")
parser.add_argument("-v", "--verbose", help="increase output verbosity", action="store_true")
args = parser.parse_args()
#Flagset
verbose = args.verbose
#Functions
def init():
    global verbose
    os.mkdir(".scratch-modules")
    if verbose:
        print("INFO || Making modules directory.")
# Main
if args.cmd == "init":
    init()
    